# Activity 1

Activity 1 uses a flat file for the persistent comment store

# Activity 2

Activity 2 uses MongoDB for the persistent user store, answer store, and question store.