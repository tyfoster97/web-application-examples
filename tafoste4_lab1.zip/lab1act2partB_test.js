const { Calc, exec } = require('./lab1act2partB');
console.log('TESTING calc()');
var c = new Calc();

console.log(c.calc('{"op": "add", "number": 5}')); // expected: 5
console.log(c.calc('{"op": "subtract", "number": 2}')); // expected: 3
console.log(c.calc('{"op": "add", "number": 19}')); // expected: 22
console.log(c.calc('{"op": "subtract", "expr": {"op": "add", "number": 15}}')); // expected: 0
console.log(c.calc('{"op": "add", "expr": {"op": "add", "expr": {"op": "subtract", "number": 3}}}')); // expected -12

console.log('\n\n\n\n');
console.log('TESTING exec()');
var expB = [
  {'exp': {'op': 'add', 'number': 0}, 'expected': 0},
  {'exp': {'op': 'add', 'number': -1}, 'expected': -1},
  {'exp': {'op': 'subtract', 'number': -1}, 'expected': 0},
  {'exp': {'op': 'add', 'number': 5}, 'expected': 5},
  {'exp': {'op': 'subtract', 'number': 10}, 'expected': -5},
  {'exp': {'op': 'add', 'number': 15}, 'expected': 10},
  {'exp': {'op': 'subtract', 'expr': {'op': 'add', 'number': 15}}, 'expected': 0},
  {'exp': {'op': 'add', 'expr': {'op': 'add', 'expr': {'op': 'subtract', 'number': 3}}}, 'expected': -12}
];

let val = exec(expB);