module.exports = {
    skipComponentsWithoutExample: true,
    components: 'src/components/**/*.jsx'
}