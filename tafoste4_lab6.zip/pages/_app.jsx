import React from 'react';
import Index from './index';

export default function MyApp({ Component, pageProps }) {
    return <Component {...pageProps} />;
}
