module.exports = {
  DOG_API_KEY: 'd1399e9e-3720-408b-956c-82ecef5387b5',
  CAT_API_KEY: 'f7dc23f2-91c4-4e07-aa44-395cec1259d7'
};
