# Lab 6
Lab 6 submission

API keys are stored in data/keys.js

## DO THIS FIRST!!!
Install node modules by running the following command:

```shell
npm install
```

## Running Styleguidist

```shell
npm run style
```

## Running Next.js Server

```shell
npm run server
```

## Running Tests

```shell
npm run test
```
OR
```shell
jest
```
