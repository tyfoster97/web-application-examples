# Lab 4

## Activity 1

For activity 1 the commands should be run in a browser console.

**NOTE** there was no "Add Bing New Tab Extension" present on the webpage to edit
> activity1.html is not included in the .zip file, there would be no changes made to
> the initial file

## Activity 2

For activity 2 the entry point is ```activity2/index.html```

## Activity 3

### Test commands and expected output

#### Example

/cmd args
> output

#### Tests

/search dumb
> educated, informed, schooled

/search car
> 
**NOTE** should return nothing

/history
> 1. dumb
> 2. car

I think the movie was great and dumb at times
> I think the movie was great and **censored** at times
**NOTE** Censored comment should be appended to list of critic reviews as well, will have username attached

/count
> 1

/list
> 1.
> Actual: I think the movie was great and dumb at times
> Censored: I think the movie was great and **censored** at times
>

/clear
>
**NOTE** should return the form to the username input state